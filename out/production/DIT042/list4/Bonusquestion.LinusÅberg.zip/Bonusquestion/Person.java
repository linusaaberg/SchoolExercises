package Bonusquestion;

public class Person {
    String name;
    int age;

    public Person(String name){
        this.name=name;
    }

    public String getName(){
        return this.name;
    }

    public int getAge(){
        return this.age;
    }
}
