package Bonusquestion;
import java.util.ArrayList;
import java.util.Scanner;

public class Part5 {

    public static void main(String[] args) {

        Person linus = new Person ("Linus");
        Person julia = new Person ("Julia");
        Person oscar = new Person ("Oscar");
        Person hjalmar = new Person ("Hjalmar");
        Person judas = new Person ("Judas");
        ArrayList<Person> persons = new ArrayList<Person>(5);


        persons.add(linus);
        persons.add(julia);
        persons.add(oscar);
        persons.add(hjalmar);
        persons.add(judas);

        for(int i = 0; i < persons.size(); i++) {
            System.out.println(persons.get(i).getName());
        }

        System.out.println("-----------------");

        Person filip = new Person("Filip");
        persons.add(filip);

        for(int i = 0; i < persons.size(); i++) {
            System.out.println(persons.get(i).getName());
        }

    }
}
